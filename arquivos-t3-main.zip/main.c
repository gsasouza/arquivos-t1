/*
 * Gabriel Santos Souza nUSP: 11208176
 * Yann Amado Nunes Costa nUSP: 10746943
 */

#include "handlers.h"
#include "b_tree.h"

int main() {
  //Calls the handlers library where the operations can be called
  parse_input();
  return 0;
}
