//
// Created by Gabriel Souza on 08/05/21.
//

#ifndef T1_HANDLERS_H
#define T1_HANDLERS_H

#include <stdio.h>
#include "vehicle.h"
#include "line.h"

void parse_input();

#endif //T1_HANDLERS_H
